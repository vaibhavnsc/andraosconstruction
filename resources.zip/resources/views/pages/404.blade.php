@extends('layouts.app')

@section('content')


<section id="not-found">
    <div class="container">
        <div class="not-found">
            <img height="auto" width="auto" src="/assets/images/error.png" alt="Page Error Found">
            <div class="error-home">
                <h1>Page Not Found</h1>
                <p>The page you are looking for doesn`t exist or an other error occurred <a href="/">Go back </a>or head over to <a href="/">Andraos Construction</a> to choose a new direction</p>
            </div>
        </div>
</section>


@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.body.classList.add('page-404');
});
</script>
@endpush