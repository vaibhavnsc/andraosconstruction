@extends('layouts.app')

@php
    $seo = getPageSeoByKey('faq');

    $title = $seo->meta_title ?? 'Concrete & Masonry FAQs | Andraos Construction';

    $description = $seo->meta_description
        ?? 'Common questions about commercial concrete, asphalt, masonry & snow-melt work in Denver & the Colorado Front Range. Call (303) 915-3703.';
@endphp

@section('meta_title', $title)
@section('meta_description', $description)


@section('content')

<!-- Banner -->

<header class="page-hero">
    <div class="page-hero__bg" data-bg="assets/images/finishes.jpg" aria-hidden="true">
    </div>
    <div class="page-hero__scrim" aria-hidden="true"></div>
    <div class="container">
        <nav class="breadcrumb-mono mb-3" aria-label="Breadcrumb">
            <a href="/">Home</a> &nbsp;/&nbsp; FAQs
        </nav>
        <h1>Frequently Asked Questions</h1>
        <p class="lede on-dark mt-3 maxw-58">
            Answers to the questions property managers, HOA boards, and general contractors ask us most.
            Don&rsquo;t see yours? Give us a call &mdash; we&rsquo;re happy to help.
        </p>
    </div>
</header>


<section class="section" aria-label="Frequently asked questions">
    <div class="container">
        <div class="row g-5">

            <!-- Accordion groups (rendered by site.js) -->
            <div class="col-lg-8" id="js-faq-groups">
                <div class="faq-group">
                    <h2 class="faq-group__title ff-display display-md mb-4">General</h2>
                    <div class="accordion" id="faqGroup0">
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup0-item0" aria-expanded="false"
                                    aria-controls="faqGroup0-item0">What areas does Andraos Construction serve?</button>
                            </h3>
                            <div id="faqGroup0-item0" class="accordion-collapse collapse" data-bs-parent="#faqGroup0">
                                <div class="accordion-body">We serve the entire Colorado Front Range from our Denver
                                    headquarters — including Denver, Aurora, Boulder, Littleton, Highlands Ranch, Castle
                                    Rock, Parker, Englewood, Broomfield, Westminster, Thornton, Arvada, and Longmont —
                                    plus surrounding mountain communities. If you are not sure whether we cover your
                                    location, call us.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup0-item1" aria-expanded="false"
                                    aria-controls="faqGroup0-item1">How long has Andraos Construction been in
                                    business?</button></h3>
                            <div id="faqGroup0-item1" class="accordion-collapse collapse" data-bs-parent="#faqGroup0">
                                <div class="accordion-body">Andraos Construction has been a family-owned commercial
                                    contractor in the Denver metro since 1993 — For 30+ years of concrete, asphalt,
                                    and masonry work across the Front Range.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup0-item2" aria-expanded="false"
                                    aria-controls="faqGroup0-item2">Are you licensed, bonded, and insured?</button></h3>
                            <div id="faqGroup0-item2" class="accordion-collapse collapse" data-bs-parent="#faqGroup0">
                                <div class="accordion-body">Yes. Andraos Construction is fully licensed, bonded, and
                                    insured for commercial work. Certificates of insurance are available on request for
                                    property managers and general contractors who need them for prequalification.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup0-item3" aria-expanded="false"
                                    aria-controls="faqGroup0-item3">Do you offer a warranty?</button></h3>
                            <div id="faqGroup0-item3" class="accordion-collapse collapse" data-bs-parent="#faqGroup0">
                                <div class="accordion-body">Every Andraos engagement carries a written one-year
                                    workmanship warranty. We self-perform the work, so we stand behind it directly.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-group">
                    <h2 class="faq-group__title ff-display display-md mb-4">Services</h2>
                    <div class="accordion" id="faqGroup1">
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup1-item0" aria-expanded="false"
                                    aria-controls="faqGroup1-item0">What services do you provide?</button></h3>
                            <div id="faqGroup1-item0" class="accordion-collapse collapse" data-bs-parent="#faqGroup1">
                                <div class="accordion-body">We self-perform commercial concrete, asphalt paving and
                                    repair, masonry, snow-melt systems, HOA &amp; property-management capital renewal,
                                    and decorative concrete finishes. Because we hold our own crews and equipment, one
                                    company is accountable for the entire scope.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup1-item1" aria-expanded="false"
                                    aria-controls="faqGroup1-item1">Do you handle both commercial and residential
                                    work?</button></h3>
                            <div id="faqGroup1-item1" class="accordion-collapse collapse" data-bs-parent="#faqGroup1">
                                <div class="accordion-body">Our focus is commercial work — property management, HOAs,
                                    general contractors, developers, and asset managers. We do take select residential
                                    projects, particularly where they connect to HOA or community work.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup1-item2" aria-expanded="false"
                                    aria-controls="faqGroup1-item2">Can you sequence work around our tenants and
                                    residents?</button></h3>
                            <div id="faqGroup1-item2" class="accordion-collapse collapse" data-bs-parent="#faqGroup1">
                                <div class="accordion-body">Yes. Resident- and tenant-occupied phasing is a core part of
                                    how we work, especially on HOA and property-management programs. We sequence around
                                    traffic, trash pickup, school buses, and business hours to keep sites accessible.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup1-item3" aria-expanded="false"
                                    aria-controls="faqGroup1-item3">Do you install snow-melt systems?</button></h3>
                            <div id="faqGroup1-item3" class="accordion-collapse collapse" data-bs-parent="#faqGroup1">
                                <div class="accordion-body">Yes. We design and install hydronic snow-melt systems,
                                    embedding the tubing during the original concrete pour so the system is protected
                                    and invisible. It is most cost-effective to plan for snow-melt before the flatwork
                                    goes in.</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="faq-group">
                    <h2 class="faq-group__title ff-display display-md mb-4">Projects &amp; Scheduling</h2>
                    <div class="accordion" id="faqGroup2">
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup2-item0" aria-expanded="false"
                                    aria-controls="faqGroup2-item0">How do I request an estimate?</button></h3>
                            <div id="faqGroup2-item0" class="accordion-collapse collapse" data-bs-parent="#faqGroup2">
                                <div class="accordion-body">Call us at (303) 915-3703 or submit the form on our Contact
                                    page. For standard commercial scopes we return a detailed, line-item estimate within
                                    3–5 business days. Emergency property-management repairs get a same-day response.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup2-item1" aria-expanded="false"
                                    aria-controls="faqGroup2-item1">How quickly can you start?</button></h3>
                            <div id="faqGroup2-item1" class="accordion-collapse collapse" data-bs-parent="#faqGroup2">
                                <div class="accordion-body">Timing depends on scope and season, but we will give you a
                                    realistic schedule with the estimate — not after you have signed. We mobilize our
                                    own crews, so we control the start date rather than waiting on subcontractors.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup2-item2" aria-expanded="false"
                                    aria-controls="faqGroup2-item2">Do you provide estimates HOAs can use in a reserve
                                    study?</button></h3>
                            <div id="faqGroup2-item2" class="accordion-collapse collapse" data-bs-parent="#faqGroup2">
                                <div class="accordion-body">Yes. We provide assessment-grade estimates based on a
                                    current site walk that boards and reserve specialists can use directly in capital
                                    planning.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h3 class="accordion-header"><button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#faqGroup2-item3" aria-expanded="false"
                                    aria-controls="faqGroup2-item3">Who manages my project?</button></h3>
                            <div id="faqGroup2-item3" class="accordion-collapse collapse" data-bs-parent="#faqGroup2">
                                <div class="accordion-body">One Andraos project manager owns your engagement from the
                                    first site walk through final punch and warranty — no handoffs and no
                                    finger-pointing between trades.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Help aside -->
            <aside class="col-lg-4" aria-label="Still have questions">
                <div class="sidebar-cta">
                    <h2>Still have questions?</h2>
                    <p class="text-white-50 small mt-2 mb-4">
                        Talk to a project manager directly — not a call center. We’ll walk you through
                        scope, schedule, and next steps.
                    </p>
                    <a href="tel:+13039153703" class="btn btn-light-navy btn-arrow w-100 mb-2">Call (303) 915-3703</a>
                    <a href="contact" class="btn btn-outline-light btn-arrow w-100">Request an Estimate</a>
                </div>
            </aside>

        </div>
    </div>
</section>


<!-- ====================== CTA ====================== -->
<section class="section bg-navy-deep text-white text-center" aria-labelledby="faq-cta-heading">
    <div class="container reveal">
        <h2 id="faq-cta-heading" class="ff-display display-xl text-white mx-auto maxw-20">Ready to get started?</h2>
        <p class="lede on-dark mt-3 mx-auto maxw-48">
            Quotes in 3&ndash;5 business days. Emergencies same-day. Call us or request a proposal online.
        </p>
        <div class="d-flex gap-2 justify-content-center mt-4 flex-wrap">
            <a href="contact" class="btn btn-light-navy btn-arrow">Request an Estimate</a>
            <a href="tel:+13039153703" class="btn btn-outline-light btn-arrow">(303)&nbsp;915-3703</a>
        </div>
    </div>
</section>

@endsection

<script type="application/ld+json">
{
  "@@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "What areas does Andraos Construction serve?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We serve the entire Colorado Front Range from our Denver headquarters — including Denver, Aurora, Boulder, Littleton, Highlands Ranch, Castle Rock, Parker, Englewood, Broomfield, Westminster, Thornton, Arvada, and Longmont — plus surrounding mountain communities. If you are not sure whether we cover your location, call us."
    }
  },{
    "@type": "Question",
    "name": "How long has Andraos Construction been in business?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Andraos Construction has been a family-owned commercial contractor in the Denver metro since 1993 — more than 30 years of concrete, asphalt, and masonry work across the Front Range."
    }
  },{
    "@type": "Question",
    "name": "Are you licensed, bonded, and insured?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes. Andraos Construction is fully licensed, bonded, and insured for commercial work. Certificates of insurance are available on request for property managers and general contractors who need them for prequalification."
    }
  },{
    "@type": "Question",
    "name": "Do you offer a warranty?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Every Andraos engagement carries a written one-year workmanship warranty. We self-perform the work, so we stand behind it directly."
    }
  },{
    "@type": "Question",
    "name": "What services do you provide?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "We self-perform commercial concrete, asphalt paving and repair, masonry, snow-melt systems, HOA & property-management capital renewal, and decorative concrete finishes. Because we hold our own crews and equipment, one company is accountable for the entire scope."
    }
  },{
    "@type": "Question",
    "name": "Do you handle both commercial and residential work?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Our focus is commercial work — property management, HOAs, general contractors, developers, and asset managers. We do take select residential projects, particularly where they connect to HOA or community work."
    }
  },{
    "@type": "Question",
    "name": "Can you sequence work around our tenants and residents?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes. Resident- and tenant-occupied phasing is a core part of how we work, especially on HOA and property-management programs. We sequence around traffic, trash pickup, school buses, and business hours to keep sites accessible."
    }
  },{
    "@type": "Question",
    "name": "Do you install snow-melt systems?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes. We design and install hydronic snow-melt systems, embedding the tubing during the original concrete pour so the system is protected and invisible. It is most cost-effective to plan for snow-melt before the flatwork goes in."
    }
  },{
    "@type": "Question",
    "name": "How do I request an estimate?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Call us at (303) 915-3703 or submit the form on our Contact page. For standard commercial scopes we return a detailed, line-item estimate within 3–5 business days. Emergency property-management repairs get a same-day response."
    }
  },{
    "@type": "Question",
    "name": "How quickly can you start?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Timing depends on scope and season, but we will give you a realistic schedule with the estimate — not after you have signed. We mobilize our own crews, so we control the start date rather than waiting on subcontractors."
    }
  },{
    "@type": "Question",
    "name": "Do you provide estimates HOAs can use in a reserve study?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes. We provide assessment-grade estimates based on a current site walk that boards and reserve specialists can use directly in capital planning."
    }
  },{
    "@type": "Question",
    "name": "Who manages my project?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "One Andraos project manager owns your engagement from the first site walk through final punch and warranty — no handoffs and no finger-pointing between trades."
    }
  }]
}
</script>