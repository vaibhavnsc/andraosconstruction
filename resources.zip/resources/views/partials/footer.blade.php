<footer class="site-footer">
    <div class="container">

        <div class="row footer-top">

            <!-- Logo -->
            <div class="col-lg-4 col-md-12 footer-brand">

                <a href="/"><img height="auto" width="auto" src="{{ asset('assets/images/logo.png') }}" alt="Andraos Construction"
                        class="footer-logo"></a>
                <p class="footer-tagline">
                    Commercial concrete, asphalt & masonry
                    for the Colorado Front Range since 1993.
                </p>

            </div>

            <!-- Services -->
            <div class="col-lg-2 col-6 service-area">

                <h6>Services</h6>

                <a href="{{ route('services.commercial-concrete') }}" class="footer-link">Commercial Concrete</a>
                <a href="{{ route('services.asphalt') }}" class="footer-link">Asphalt Paving</a>
                <a href="{{ route('services.masonry') }}" class="footer-link">Masonry</a>
                <a href="{{ route('services.snow-melt') }}" class="footer-link">Snow Melt Systems</a>
                <a href="{{ route('services.hoa-and-residential') }}" class="footer-link"> HOA & Residential</a>

            </div>

            <!-- Service Areas -->
            <div class="col-lg-4 col-6 service-area">

                <h6>Service Areas</h6>

                <div class="footer-areas">

                    <div>
                        <a href="{{ route('areas.denver') }}" class="footer-link">Denver</a>
                        <a href="{{ route('areas.aurora') }}" class="footer-link">Aurora</a>
                        <a href="{{ route('areas.littleton') }}" class="footer-link">Littleton</a>
                        <a href="{{ route('areas.highlands-ranch') }}" class="footer-link">Highlands Ranch</a>
                        <a href="{{ route('areas.castle-rock') }}" class="footer-link">Castle Rock</a>
                        <a href="{{ route('areas.parker') }}" class="footer-link">Parker</a>
                        <a href="{{ route('areas.englewood') }}" class="footer-link">Englewood</a>
                    </div>

                    <div>
                        <a href="{{ route('areas.broomfield') }}" class="footer-link">Broomfield</a>
                        <a href="{{ route('areas.boulder') }}" class="footer-link">Boulder</a>
                        <a href="{{ route('areas.westminster') }}" class="footer-link">Westminster</a>
                        <a href="{{ route('areas.thornton') }}" class="footer-link">Thornton</a>
                        <a href="{{ route('areas.arvada') }}" class="footer-link">Arvada</a>
                        <a href="{{ route('areas.longmont') }}" class="footer-link">Longmont</a>
                    </div>

                </div>

            </div>

            <!-- Company -->
            <div class="col-lg-2 col-12 fbo">

                <h6>Company</h6>

                <a href="tel:+13039153703" class="footer-link">
                    (303) 915-3703
                </a>

                <a href="/about" class="footer-link">About</a>
                <a href="/faqs" class="footer-link">FAQ</a>
                <a href="/#Google-reviews" class="footeRequest an Estimate</a>
                <a href="/contact" class="footer-link">Request An Estimate</a>

            </div>

        </div>

        <div class="footer-bottom">

            <div class="footer-copyright">
                © 2026 <a href="/">ANDRAOS CONSTRUCTION</a> · DENVER, CO ·
                LICENSED & INSURED · EST. 1993
            </div>

            <div class="footer-legal">
                <a href="/privacy">Privacy</a>
                <a href="/terms">Terms</a>
            </div>

        </div>

    </div>
</footer>

<nav id="mobile-cta" aria-label="Quick contact" class="mobile-cta">
    <a href="tel:+13039153703">☏ Call</a>
    <a href="sms:+13039153703">✉ Text</a>
    <a href="/contact" class="is-primary">→ Quote</a>
</nav>
