<!-- ════ CONTACT ════ -->
<section class="section bg-navy text-white" id="contact" style="border-top:1px solid rgba(255,255,255,.06)">
  <div class="container">
    <div class="row g-5 mb-5 reveal">
      <div class="col-lg-6">
        <div class="eyebrow on-dark">Get in Touch</div>
        <h2 class="ff-display display-lg mt-3 text-white">Start the Conversation</h2>
      </div>
      <div class="col-lg-6 d-flex align-items-end">
        <p class="lede" style="color:var(--slate-300)">Quotes in 3–5 business days. Emergencies same-day. Call us or
          send the scope below.</p>
      </div>
    </div>
    <div class="row g-5">
      <div class="col-lg-5">
        <div class="d-flex gap-3 pb-4 mb-4 border-bottom" style="border-color:rgba(255,255,255,.1)">
          <div class="contact-icon">☏</div>
          <div>
            <div class="field-label" style="color:rgba(255,255,255,.55)">Direct Line</div>
            <div class="ff-display fs-4 text-white"><a href="tel:(303) 915-3703" class="text-white">(303) 915-3703</a>
            </div>
            <div class="text-slate" style="font-size:13px;color:rgba(255,255,255,.6)!important">Mon–Fri · 6am–6pm ·
              Speak with estimating.</div>
          </div>
        </div>
        <div class="d-flex gap-3 pb-4 mb-4 border-bottom" style="border-color:rgba(255,255,255,.1)">
          <div class="contact-icon">⌂</div>
          <div>
            <div class="field-label" style="color:rgba(255,255,255,.55)">Service Territory</div>
            <div class="ff-display fs-4 text-white">Denver Metro &amp; Front Range</div>
            <div style="font-size:13px;color:rgba(255,255,255,.6)">Boulder, Douglas County &amp; mountain communities.
            </div>
          </div>
        </div>
        <div class="d-flex gap-3">
          <div class="contact-icon">◷</div>
          <div>
            <div class="field-label" style="color:rgba(255,255,255,.55)">Established</div>
            <div class="ff-display fs-4 text-white">1993 · Licensed &amp; Insured</div>
            <div style="font-size:13px;color:rgba(255,255,255,.6)">Bonded for commercial. Certificates on request.</div>
          </div>
        </div>
      </div>
      <div class="col-lg-7">
        <div class="bg-white p-4 p-md-5" style="border-radius:4px">
          <!-- <form id="quoteForm" class="text-dark">
            <h3 class="ff-display" style="color:var(--navy-900);font-size:26px">Request a Commercial Estimate</h3>
            <p class="text-slate mb-4" style="font-size:13px">Reply within 1 business day · Site walks within the week.</p>
            <div class="row g-3">
              <div class="col-md-6"><div class="field-label">Full name</div><input class="form-control" required placeholder="Jane Doe"></div>
              <div class="col-md-6"><div class="field-label">Company / Property</div><input class="form-control" placeholder="Required for commercial"></div>
              <div class="col-md-6"><div class="field-label">Email</div><input type="email" class="form-control" required placeholder="you@company.com"></div>
              <div class="col-md-6"><div class="field-label">Phone</div><input type="tel" class="form-control" placeholder="(303) 000-0000"></div>
              <div class="col-md-6"><div class="field-label">Scope</div><select class="form-select"><option>Commercial Concrete</option><option>Asphalt Paving</option><option>Masonry</option><option>Snow Melt</option><option>HOA / Property Mgmt</option><option>Other</option></select></div>
              <div class="col-md-6"><div class="field-label">Approx. size</div><input class="form-control" placeholder="e.g. 12,000 SF"></div>
              <div class="col-12"><div class="field-label">Project scope &amp; schedule</div><textarea class="form-control" rows="4" placeholder="Describe the property, scope of work, and schedule."></textarea></div>
              <div class="col-12"><button type="submit" class="btn btn-navy btn-arrow w-100">Send Estimate Request</button></div>
            </div>
          </form> -->
          <form id="quoteForm" method="POST">
            @csrf

            <h3 class="ff-display" style="color:var(--navy-900);font-size:26px">
              Request a Commercial Estimate
            </h3>

            <p class="text-slate mb-4" style="font-size:13px">
              Reply within 1 business day · Site walks within the week.
            </p>

            <div class="row g-3">

              <div class="col-md-6">
                <div class="field-label">Full Name</div>
                <input type="text" name="full_name" class="form-control" required placeholder="Jane Doe">
              </div>

              <div class="col-md-6">
                <div class="field-label">Company / Property</div>
                <input type="text" name="company" class="form-control" placeholder="Required for commercial">
              </div>

              <div class="col-md-6">
                <div class="field-label">Email</div>
                <input type="email" name="email" class="form-control" required placeholder="you@company.com">
              </div>

              <div class="col-md-6">
                <div class="field-label">Phone</div>
                <input type="text" name="phone" class="form-control" placeholder="(303) 000-0000">
              </div>

              <div class="col-md-6">
                <div class="field-label">Scope</div>
                <select name="scope" class="form-select">
                  <option>Commercial Concrete</option>
                  <option>Asphalt Paving</option>
                  <option>Masonry</option>
                  <option>Snow Melt</option>
                  <option>HOA / Property Mgmt</option>
                  <option>Other</option>
                </select>
              </div>

              <div class="col-md-6">
                <div class="field-label">Approx. Size</div>
                <input type="text" name="approx_size" class="form-control" placeholder="e.g. 12,000 SF">
              </div>

              <div class="col-12">
                <div class="field-label">Project Scope & Schedule</div>
                <textarea name="message" rows="4" class="form-control"
                  placeholder="Describe the property, scope of work, and schedule."></textarea>
              </div>

              <div class="col-12">
                <button type="submit" class="btn btn-navy btn-arrow w-100">
                  Send Estimate Request
                </button>
              </div>

            </div>

            <div id="successMessage" class="alert alert-success mt-3 d-none"></div>
            <div id="errorMessage" class="alert alert-danger mt-3 d-none"></div>

          </form>
          <div id="formSuccess" class="text-center py-5 d-none">
            <div class="ff-mono text-uppercase mb-3" style="font-size:11px;letter-spacing:.18em;color:var(--slate-500)">
              Request Received</div>
            <h3 class="ff-display" style="color:var(--navy-900)">Thank you.</h3>
            <p class="text-slate mx-auto" style="max-width:36ch;font-size:14px">An Andraos project manager will contact
              you within one business day to confirm scope and schedule a site walk.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>
$(document).ready(function(){

    $("#quoteForm").submit(function(e){
        e.preventDefault();

        $("#successMessage").addClass('d-none');
        $("#errorMessage").addClass('d-none');

        $.ajax({
            url: "{{ route('quote.submit') }}",
            type: "POST",
            data: $(this).serialize(),

            success: function(response){

                $("#successMessage")
                    .removeClass('d-none')
                    .html(response.message);

                $("#quoteForm")[0].reset();
            },

            error: function(xhr){

                if(xhr.status == 422){

                    let errors = xhr.responseJSON.errors;
                    let errorHtml = '';

                    $.each(errors, function(key, value){
                        errorHtml += value[0] + "<br>";
                    });

                    $("#errorMessage")
                        .removeClass('d-none')
                        .html(errorHtml);

                }else{

                    $("#errorMessage")
                        .removeClass('d-none')
                        .html("Something went wrong.");

                }
            }

        });

    });

});
</script>