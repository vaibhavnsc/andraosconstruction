 <!-- ====================== CTA ====================== -->
    <section class="section bg-navy-deep text-white text-center" aria-labelledby="svc-cta-heading">
      <div class="container reveal">
        <h2 id="svc-cta-heading" class="ff-display display-xl text-white mx-auto maxw-20">Have a scope in mind?</h2>
        <p class="lede on-dark mt-3 mx-auto maxw-48">Send it over and we&rsquo;ll return a detailed estimate in 3&ndash;5 business days.</p>
        <div class="d-flex gap-2 justify-content-center mt-4 flex-wrap">
          <a href="/contact" class="btn btn-light-navy btn-arrow">Request a Quote</a>
          <a href="tel:+13039153703" class="btn btn-outline-light btn-arrow">(303)&nbsp;915-3703</a>
        </div>
      </div>
    </section>